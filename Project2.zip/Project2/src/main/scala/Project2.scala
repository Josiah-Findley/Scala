/************************************************
**Josiah Findley ~ COMP433.A ~ Spring 2021****
**
**Project 2

1.	[5 points] State one function you defined in the Overlap Graph problem that qualifies as a closure. 
List its file and line number so I can easily find it. 
State the variable(s) from the environment that were closed over and used in the closure.

Lines - :
//def apply(n: Int): (String, String) => Boolean = {

            ****Function that qualifies as closure****
             ********(s:String, s2:String)=> {
                if(s!=s2 && s.substring(s.length-n,s.length)==s2.substring(0,n)) true else false********
            }//
******n was closed over and used in the closure.*******

2.	[1 point] What was one problem that you think was easier to solve using functional programming style
 than iterative/imperative style (i.e., modifying state in a for loop)? Why do you think so?

consensus was easier to solve using functional programming bc the for/yield comprehension along with the 
mkString method made it quite easy to organize the data into a list and then immediately into a string

3.	[1 point] What was one problem that you think was harder to solve using functional programming style
 than iterative/imperative style (i.e., modifying state in a for loop)? Why do you think so?

 gcContent was harder to solve using functional programming bc you had to yield a list and then take its
 size to find the number of Gs and Cs instead of just having a simple counter

*/

//Imports
import scala.annotation.tailrec
import CodonTable.getAminoAcid
import CodonTable.countCodons

//Question 1
class Fasta (val name:String, val dna:String){
   def gcContent():Double = {
    //If G or C add and then take percentage
    ((for(c<-dna if(c=='G'||c=='C')) yield c).size).toDouble/dna.length
   }
}

object Fasta{
    def parseFastas(s: String): List[Fasta] ={
        //Parse at >
        val s2 = s.split(">").toList.tail
        for(f<-s2) yield{
            //Make list of fastas (made by turning tail of list into string)
            new Fasta(f.split("\\n")(0),f.split("\\n").toList.tail.mkString(""))           
        } 
    }
}

object ProjectTwo{
    //Question 2
   def translateRna(rna: String): String = {
    //Translate rna 3 letters at a time
    (for(i<-0 to rna.length-3 by 3) yield(if(getAminoAcid(rna.substring(i, i+3)) !="Stop") getAminoAcid(rna.substring(i, i+3)) else "")
    ).mkString
   }
   // Question 3
   def countSources (protien: String): Int = {
    //Grab count for each letter
    val xs = (for(c<-protien) yield countCodons(c.toString)).toList
    //Calculate total mod 1000000 using tail recursion
    @tailrec
    def helper(xs:List[Int], acc:Int):Int= xs match{
        case Nil => acc
        case _ => helper(xs.tail, (xs.head*acc)%1000000)
    }
    helper(xs,3)
   }

   //Question 4.1
   def profile(ss: Seq[String]): Seq[Map[Char, Int]] ={
       val len = ss.maxBy(_.length).length //grab len
       //Make list of list
       val positionGroups = (for(j<-0 until len) yield{ 
                                (for(s<-ss) yield{
                                        s(j)}).toList}).toList

    //Make list of maps
    for( x <- positionGroups ) yield {         
           x.groupBy( (c: Char) => c ).map( kv => (kv._1, kv._2.length))
      }
   }

    //Question 4.2
   def consensus(ss: Seq[String]): String ={
       //grab map
       val map = profile(ss)
       //Make String out of most common symbols
       (for(m<-map)yield m.maxBy(_._2)._1).mkString
   }
}
    //Question 5
    object OverlapFunction{
        def apply(n: Int): (String, String) => Boolean = {
            //Return true if not equal and there is overlap else return false
             (s:String, s2:String)=> {
                if(s!=s2 && s.substring(s.length-n,s.length)==s2.substring(0,n)) true else false
            }
        }
    }

    //Question 5 (p2)
    object NoisyOverlapFunction{
        def apply(n: Int, pointMutationsAllowed: Int): (String, String) => Boolean= {
            (s:String, s2:String)=> {
                //Check if less than overlap value
                if(s.length<n ||s2.length<n){
                    false
                }else{
                    val sCheck  = s.substring(s.length-n,s.length) //s overlap string
                    val s2Check = s2.substring(0,n)//s2 overlap string
                    //Count Point Mutations
                    val pointMutations = (for(i<-0 until sCheck.length if(sCheck(i)!=s2Check(i)))yield sCheck(i)).size
                    //Return True if not equal and pointMutations<=pointMutationsAllowed else return false
                    if(s!=s2 && pointMutations<=pointMutationsAllowed) true else false
                }
            }
        }
    }




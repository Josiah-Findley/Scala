import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class TranslateRNASpec extends AnyFlatSpec with Matchers {

  "translateRna" should "translate RNA sequences to amino acid sequences" in {
    ProjectTwo.translateRna("UAG") should equal ("")
    ProjectTwo.translateRna("GCCUAA") should equal ("A")
    ProjectTwo.translateRna("CGAUAG") should equal ("R")
    ProjectTwo.translateRna("UAUUUGAAGGGAUAUUGA") should equal ("YLKGY")
    ProjectTwo.translateRna("UAUCGACGAUAA") should equal ("YRR")
  }
 
}
import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class CountResultsSpec extends AnyFlatSpec with Matchers {
    "countResults" should "return an empty map on an empty input" in {
        ExamOne.countResults(List[String](), (s: String) => s.length) should equal (Map[Int,Int]())
        ExamOne.countResults(List[String](), (s: String) => s charAt 0) should equal (Map[Char,Int]())
    }

    it should "correctly handle generic types" in {
        val xf = List(-20, -8, 8)
        ExamOne.countResults(xf, Math.abs) should equal (Map(20 -> 1, 8 -> 2))
        val xs = List("hello", "world", "fizz", "buzz", "foo", "bar", "fizzbuz")
        ExamOne.countResults(xs, (s: String) => s.length) should equal (Map(
            3 -> 2, 
            4 -> 2, 
            5 -> 2, 
            7 -> 1
        ))
        ExamOne.countResults(xs, (s: String) => s charAt 0) should equal (Map(
            'h' -> 1,
            'w' -> 1,
            'f' -> 3,
            'b' -> 2
        ))
    }
}

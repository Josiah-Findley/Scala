import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class MinSpec extends AnyFlatSpec with Matchers {
    "min" should "return Double.MaxValue on an empty list" in {
        ExamOne.min(List[Double]()) should equal (Double.MaxValue)
    }

    it should "return the only value in a single element list" in {
        ExamOne.min(List(99.0)) should equal (99.0)
        ExamOne.min(List(42.0)) should equal (42.0)
        ExamOne.min(List(-111.111)) should equal (-111.111)
    }

    it should "identify the min when it is the first element in the list" in {
        ExamOne.min(List(1.0, 3.0, 8.0, 9.0)) should equal (1.0)
        ExamOne.min(List(-100.0, -1.0, 74.0, 42.0)) should equal (-100.0)
    }

    it should "identify the min when it is the last element in the list" in {
        ExamOne.min(List(3.0, 8.0, 9.0, 1.0)) should equal (1.0)
        ExamOne.min(List(-1.0, 74.0, 42.0, -100.0)) should equal (-100.0)
    }

    it should "identify the min when falls in the middle of the list" in {
        ExamOne.min(List(3.0, 1.0, 8.0, 9.0)) should equal (1.0)
        ExamOne.min(List(-1.0, 74.0, -100.0, 42.0)) should equal (-100.0)
    }
}
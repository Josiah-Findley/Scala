import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class MakeMultiplierSpec extends AnyFlatSpec with Matchers {
    "makeMultiplier" should "return a function that handles empty lists" in {
        ExamOne.makeMultiplier(2.0)(List[Double]()) should equal (List[Double]())
    }

    it should "return a function that doubles a list of Doubles" in {
        ExamOne.makeMultiplier(2.0)(List(5, 6, 7)) should equal (List(10, 12, 14))
        ExamOne.makeMultiplier(2.0)(List(0, 2, 4)) should equal (List(0, 4, 8))
    }

    it should "return a function that triples a list of Doubles" in {
        ExamOne.makeMultiplier(3.0)(List(5, 6, 7)) should equal (List(15, 18, 21))
        ExamOne.makeMultiplier(3.0)(List(0, 2, 4)) should equal (List(0, 6, 12))
    }
}
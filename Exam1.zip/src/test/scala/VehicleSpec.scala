import org.scalatest.flatspec.AnyFlatSpec
import org.scalatest.matchers.should.Matchers

class VehicleSpec extends AnyFlatSpec with Matchers {
    "Vehicle" should "be the superclass of Bicycle and Car" in {
        val vs = List(new Car("Yellow"), new Bicycle("Blue"), new Car("Red"))
        for (e <- vs) { 
            (e match {
                case v: Vehicle => true
                case _ => false
            }) should equal (true)
        }
    }

    it should "store color as a public variable in Vehicle" in {
        val vs: List[Vehicle] = List(new Car("Yellow"), new Bicycle("Blue"), new Car("Red"))
        vs(0).color should equal ("Yellow")
        vs(1).color should equal ("Blue")
        vs(2).color should equal ("Red")
    }

    it should "use an appropriate number of wheels for cars and bicycles" in {
        val vs: List[Vehicle] = List(new Car("Yellow"), new Bicycle("Blue"), new Car("Red"))
        vs(0).numWheels should equal (4)
        vs(1).numWheels should equal (2)
        vs(2).numWheels should equal (4)
    }

    it should "appropriately override motorized in Car and Bicycle" in {
        val vs: List[Vehicle] = List(new Car("Yellow"), new Bicycle("Blue"), new Car("Red"))
        vs(0).motorized should equal (true)
        vs(1).motorized should equal (false)
        vs(2).motorized should equal (true)
    }
}
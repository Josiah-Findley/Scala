object ExamOne {
    // TODO: problemOne
    def problemOne() = for(x<-1 to 50) yield x*x
    
    // TODO: makeMultiplier
    def makeMultiplier(c:Double):List[Double]=>List[Double]={
        (xs:List[Double]) => for(x<-xs) yield c*x
    }
    
    // TODO: min
    def min(xs:List[Double]):Double= xs match{
        case Nil => Double.MaxValue
        case _ => Math.min(min(xs.tail), xs.head)
    }
    
    // problem four
    def countResults[A,B](xs: List[A], f: A=>B): Map[B, Int] = {
        // TODO: complete this
         val tbl = scala.collection.mutable.Map[B, Int]()
        for(x <- xs)
            tbl(f(x))=tbl.getOrElse(f(x),0)+1 
        tbl.toMap
    }       
}

import scala.util.control.Breaks._

// Problem 5
trait Logged {
  def log(msg: String)
}

trait Emailer extends Logged {
    private var triggers: Seq[String] = Nil
    private var recipients: Seq[String] = Nil
    abstract override def log(msg: String): Unit = {
      super.log(msg)
      var trigger = false
      for(trig<-triggers){
        if(msg.contains(trig)){
          trigger = true
        }
      }
      if(trigger) sendEmail(msg)
    }
    def setTriggers(newTriggers: Seq[String]) = { triggers = newTriggers }
    def setRecipients(newRecipients: Seq[String]) = { recipients = newRecipients }
    def sendEmail(msg: String): Unit = { recipients.foreach {
      name =>  println(s"Email sent to $name") } }
}

class FileSystemMonitor(val dev: String = "/dev/sda") extends Logged {
    // methods would go here
    def log(msg: String): Unit={}
}

object TheMonitors {
    // TODO: create the two monitors here
    val fileSys = new FileSystemMonitor("C:") with Emailer
    val fileSys2 = new FileSystemMonitor("Z:")
  
    
}

/* TODO: answer the question about traits in a comment here
  Mixing them in when they are created allows us to decide whether we
  want that object to have said trait whereas if FileSystemMonitor extended 
  Emailer then every instance of FileSystemMonitor would have to mixin the 
  Emailer trait. (we instead might want to mixin a different trait and not the
  Emailer one.)
*/


// TODO: add abstract method
abstract class Vehicle(val numWheels: Int, val color: String) {
    def motorized():Boolean

}

// TODO: create Car
class Car(override val color: String) extends Vehicle(4, color){
    override def motorized():Boolean = true
}

// TODO: create Bicycle
class Bicycle(override val color: String) extends Vehicle(2, color){
    override def motorized():Boolean = false
}
object likesAndDislikes{
    def main(args: Array[String])={
        //Grab input
        val bobsString = scala.io.StdIn.readLine()  
        val alicesString = scala.io.StdIn.readLine()

        val lenStr = bobsString.length //Get length

        println((for(i<-0 to lenStr; if(bobsString(i)==alicesString(i))) yield                     i).length)
    }    
}   
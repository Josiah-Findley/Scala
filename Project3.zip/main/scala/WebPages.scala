package WebPages

class WebPage(val id: String, val name: String, val url: String,
              val text: String, val links: List[String]) {
    // When given a weight a RankedWebPage is returned matching the 
    // WebPage called on + the supplied weight
    def convertToRanked(weight: Double): RankedWebPage = {
        new RankedWebPage(this.id, this.name, this.url, this.text, this.links, weight)
    }
}

class RankedWebPage(override val id: String, override val name: String, override val url: String,
              override val text: String, override val links: List[String], val weight: Double) 
              extends WebPage(id, name, url, text, links) {
    // When given a tectmatch score a SearchedWebPage is returned matching the 
    // RankedWebPage called on + the supplied textmatch
    def convertToSearched(textmatch: Double) = {
        new SearchedWebPage(this.id, this.name, this.url, this.text, this.links, this.weight, textmatch)
    }
}

class SearchedWebPage(override val id: String, override val name: String, override val url: String,
              override val text: String, override val links: List[String],
              override val weight: Double, val textmatch: Double) 
              extends RankedWebPage(id, name, url, text, links, weight) {

}
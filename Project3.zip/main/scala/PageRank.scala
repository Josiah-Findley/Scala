package PageRank
import scala.util.Random
import scala.collection.parallel.CollectionConverters._
import WebPages._

object PageRank {
    def equal(pages: Map[String, WebPage]): Map[String, Double] = {
        pages.map(page => (page._1, 1.0)).toMap
    }

    def indegree(pages: Map[String, WebPage]): Map[String, Double] = {
        pages.map(page => (page._1, numberOfOtherLinks(page._1, pages))).toMap
    }


// id - the page id we are searching for in all other links
// pages - all other links
    def numberOfOtherLinks(id: String, pages: Map[String, WebPage]): Double = {
        pages.foldLeft(0.0)((sum: Double, p: (String, WebPage)) => {
            sum + p._2.links.foldLeft(0.0)((sum2, link) => 
                if(link == id) sum2 + 1.0 else sum2
            )
        })
    }
}
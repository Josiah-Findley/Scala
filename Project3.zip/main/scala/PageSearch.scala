package PageSearch
//Imports
import WebPages.WebPage
import WebPages.RankedWebPage
import WebPages.SearchedWebPage
import scala.math.log
import scala.collection.parallel.CollectionConverters._

object PageSearch {
    def count(pages: List[RankedWebPage], query: List[String]): List[Double] = {
        for(rw<-pages)yield{//for each page
            //for each query keep total count of num times in doc 
           (for(q<-query; i<- 0 until rw.text.length-q.length; if(rw.text.substring(i, i+q.length)==q)) yield q).length 
        }
    }
    def tf(pages: List[RankedWebPage], query: List[String]): List[Double] = {
        for(rw<-pages)yield{ //for each page
            //for each query keep total count of num times in doc and divide by len of doc
           (for(q<-query; i<- 0 until rw.text.length-q.length; if(rw.text.substring(i, i+q.length)==q)) yield q).length.toFloat/rw.text.length 
        }
    }
    def tfidf(pages: List[RankedWebPage], query: List[String]): List[Double] = {
        val n = 700;//num docs
        val d = for(q<-query)yield{ //num docs that contain item 
                    (for(rw<-pages; if(rw.text.contains(q))) yield rw).length 
                }
        val idf = for(count<-d)yield{math.log(n.toFloat/(count+1))}//calculate idf for each query

        val queryTfIdfVal= for(i<-0 until query.length)yield{   //for each query map to respective tf
                    tf(pages, List(query(i))).map((x)=>x*idf(i)) 
                }
        
        queryTfIdfVal.transpose.map(_.sum).toList //add idf for each query together and return for each page
    }
    
}
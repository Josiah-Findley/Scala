import WebPages.WebPage
import WebPages.RankedWebPage
import WebPages.SearchedWebPage
import PageRank.PageRank
import PageSearch.PageSearch

import scala.io.Source
import scala.io.StdIn.readLine
import scala.util.control.Breaks._

object AskWillie {
    def main(args: Array[String]) = {
        println("=============================================================")
        println("   _____          __      __      __.__.__  .__  .__ ")
        println("  /  _  \\   _____|  | __ /  \\    /  \\__|  | |  | |__| ____  ")
        println(" /  /_\\  \\ /  ___/  |/ / \\   \\/\\/   /  |  | |  | |  |/ __ \\")
        println("/    |    \\___ \\|     <   \\        /|  |  |_|  |_|  \\  ___/ ")
        println("\\____|__  /____  >__|_ \\   \\__/\\  / |__|____/____/__|\\___  >")
        println("        \\/     \\/     \\/        \\/                       \\/")
        println("=============================================================")

        // Load WebPage.id -> WebPage map to better handle graph
        val pages: Map[String, WebPage] = mapWebPages(loadWebPages)

        // Rank the webpages and get the min & max values
        val rankedUnweighted = PageRank.indegree(pages)
        val max = rankedUnweighted.valuesIterator.max
        val min = rankedUnweighted.min._2
        // println(rankedUnweighted)
        // println(max + " and " + min)
        // println((for(i <- pages) yield normalize(rankedUnweighted.getOrElse(i._1, 0.0), max, min)).max)

        // Normalize the ranks and convert the WebPages to RankedWebPages 
        // (if max = min then the ranks will all be 1)
        val rankedPages: List[RankedWebPage] = (for(x <- pages) yield x._2.convertToRanked(
            if(min == max) 1.0 else normalize(rankedUnweighted.getOrElse(x._1, 0.0), max, min))
        ).toList

        // println(rankedPages)
        // println(for(i <- rankedPages) yield i.weight)
        // println(rankedPages.getOrElse("8c70ed17dda23380", new RankedWebPage("", "", "", "", List(""), 0.0)).weight)

        // Main loop
        var run: Boolean = true;
        while(run){

            // Prompt and read user input
            print("Ask: ")
            val input = scala.io.StdIn.readLine().split(" ").toList
            //println(input)

            // If the user inputs :quit, end the loop
            if(input(0) == ":quit"){
                //break
                run = false
            }

            // println(PageSearch.tf(rankedPages, input))

            // Compute the textmatch scores and get the min & max values
            val searchResults: List[Double] = PageSearch.tfidf(rankedPages, input)
            val max = searchResults.max
            val min = searchResults.min
            // println(max + " and " + min)

            // Normalize the textmatch scores, convert to SearchedWebPage, and sort the pages
            val searchedPages: List[SearchedWebPage] = (
                for(x <- 0 until rankedPages.length) yield 
                rankedPages(x).convertToSearched(if(min == max) 1.0 else 
                normalize(searchResults(x), max, min))
            ).toList.sortWith(meanSort)
            // println(searchedPages)
            // println((for(i <- searchedPages) yield i.weight))

            // print out the top 10 pages
            for(i <- 0 until 10) println(searchedPages(i).name + " " )
        }
    }

    // When given a value, max, and min the normalized value is returned
    def normalize(x: Double, max: Double, min: Double): Double = {
        (x - min)/(max - min)
    }

    // Sorting fuction that sorts by the mean of a page's weight and text match.
    // Depending on config, it can to arithmetic, geometric, or harmonic
    def meanSort(searched1: SearchedWebPage, searched2: SearchedWebPage) = {
        // Config val
        val mType = 'h';

        if(mType == 'a') { // Arithemetic mean
            ((searched1.weight + searched1.textmatch)/2) > ((searched2.weight + searched2.textmatch)/2)
        }
        else if(mType == 'g') { // Geometric mean
            (scala.math.sqrt((searched1.weight * searched1.textmatch))) > (scala.math.sqrt((searched2.weight * searched2.textmatch)))
        }
        else { // Harmonic mean
            (2/(1/searched1.weight + 1/searched1.textmatch)) > (2/(1/searched2.weight + 1/searched2.textmatch))
        }
    }

    // Load a List of WebPage objects from the packaged prolandwiki.csv file
    def loadWebPages: List[WebPage] = {
        // create an input stream to the proglangwiki.csv
        val fh = Source.fromInputStream(
            getClass.getClassLoader.getResourceAsStream("proglangwiki.csv"))
        // load all pages from the file line by line
        val pages = (for (line <- fh.getLines) yield {
            val id::name::url::text::links = line.split(",").toList
            new WebPage(id, name, url, text, links)
        }).toList
        fh.close
        pages
    }

    // Convert a List[WebPage] to a Map[String, WebPage]
    def mapWebPages(pages: List[WebPage]): Map[String, WebPage] = {
        (for (page <- pages) yield (page.id, page)).toMap
    }
}
import scala.annotation.tailrec

object examples{

    def main(args: Array[String]): Unit={
        println(parseString("2+3+342"))
        println(numThrees(List("hello", "hi","hi"), "hi"))
        itterateFunction(5)
        println(findMatching("ab", List("abacus","apple")))
        println(parseStringImmutable("2+3+342"))
        println(frequencyTable(List("hey","hey","hi")))
        println(frequencyTableTwo(List("hey","hey","hi")))
        printAll(List("sdf","as","sdfg"));
        printAll(List(45,34,5));
        println(count(List(45,34,5,5,5,4),5));

        val q = new QuizOne(6)
        println(q.x);
 
        val listBool = List(true, false, true, false)
        println(listBool.foldLeft(false){(parity, nextVal)=> (parity&&(!nextVal))||(!parity&&nextVal)})

        println(transform((x)=> x*2.5, List(1,2,3,4)))

        val smallAndOdd = both( (x: Int) => x < 10, (x: Int) => x % 2 == 1 )
        println(smallAndOdd(6))



        //assert( q.x == 6 ) 
        println(q.filterGreater( List(1, 11, 2, 12) ).toSet == Set(11, 12) )

        println(factorial2(4))
        println(addInts(List(1, 11, 2, 12)))
    }


def factorial2(n:Int):Int = {
    @tailrec
    def helper(n:Int, acc:Int):Int= n match{
        case 1 => acc
        case _ => helper(n-1, n*acc)
    }
    helper(n,1)
}

def addInts(xs:List[Int]):Int = {
    @tailrec
    def helper(xs:List[Int], acc:Int):Int= xs match{
        case Nil => acc
        case _ => helper(xs.tail, xs.head+acc)
    }
    helper(xs,0)
}


def factorial(n:Int):Int = n match{
    case 1 => 1
    case _ => n*factorial(n-1)
}


def both[A] (p1:A=>Boolean, p2:A=>Boolean): A=>Boolean = {
    x=> p1(x)&&p2(x)
}

def turns(x: Int): String=
       s"You have $x" + (if(x==1) "turn" else "turns")+" remaining"

def parseString(s: String): Int = {
    var num = 1
    for(i <- 0 until s.length) if (s(i)=='+') num+=1
num
}

def numThrees(xs: List[String], s:String): Int = xs match{
    case Nil => 0
    case _ => (if(xs.head == s) 1 else 0) + numThrees(xs.tail, s)

}

def itterateFunction(n: Int): Unit = for(i<-0 to n; j<-0 to n if(i<j)) println(s"$i $j")

def findMatching(s:String, xs: List[String]):List[String]={
    (for(x <- xs if (x contains s)) yield  x).toList
}

def parseStringImmutable(s: String): Int = {
    1+(for(i <- s if (i=='+')) yield i).length
}

def frequencyTable(xs: List[String]):Map[String, Int]={
    val tbl = scala.collection.mutable.Map[String, Int]()
    for(x <- xs)
        tbl(x) = 1 + tbl.getOrElse(x, 0)
    tbl.toMap
}

def frequencyTableTwo(xs: List[String]):Map[String, Int]={
    var tbl = Map[String, Int]()
    for(x <- xs)
        tbl = tbl + (x ->(tbl.getOrElse(x, 0)+1))
    tbl
    
}

def printAll[A](xl:List[A]):Unit = for(x<-xl) println(x)

def count [A](xl:List[A], x:A):Int = xl match{
    case Nil=>0
    case _=>(if(xl.head == x) 1 else 0) + count(xl.tail, x)
}


def transform(fn: Int=> Double, xs: List[Int]):List[Double] = {
    for(x<-xs) yield fn(x)
}

}





class QuizOne(val x:Int){

def filterGreater(xl:List[Int]):List[Int] = {
    for(z<-xl if(z>x)) yield z
}

}
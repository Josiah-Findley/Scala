object QuizTwo{

def makeClipper(f:Double=>Double, upperLimit:Double):Double=>Double ={
    (x:Double)=>{if(f(x)>upperLimit) upperLimit else f(x)}
}

}
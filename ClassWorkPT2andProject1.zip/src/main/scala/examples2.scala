abstract class Vehicle(val speed: Int){
    def name()={
        "Vehicle"
    }

}

class Car(override val speed: Int)extends Vehicle(speed){
    override def name()={
        "Car"
    }
}

class Bike(override val speed: Int)extends Vehicle(speed){
    override def name() ={
        "Bike"
    }
}

object Vehicle{
    def soundOff(v: Vehicle){
        println(s"Name: ${v.name}\nSpeed: ${v.speed}")
    }

    def main(args: Array[String]): Unit={
        val b = new Bike(10);
        val c = new Car(100);
        val v = new Bike(232384730);
        soundOff(b);
        soundOff(c);
        soundOff(v);
    }

}
/************************************************
**Josiah Findley ~ COMP443.A ~ Spring 2021
**Project 1 ~ DNATools
*************************************************/

object DNATools {

//Counts # of each symbol
  def countNucleotides(s: String): Map[Char, Int] = {
    val tbl = scala.collection.mutable.Map[Char, Int]()
    for(x <- s)
        tbl(x) = 1 + tbl.getOrElse(x, 0)
    //Set to 0 if not there
    for(y <- "ATCG")
        tbl(y) = tbl.getOrElse(y, 0)
    tbl.toMap
  }
 
//Replaces 'T' with 'U'
  def transcribe(s: String): String = {
      for(c <- s ) yield (if (c=='T')'U' else c)
  }

//Reverse DNA and then complements it
  def reverseComplement(s: String): String ={
      for(c <- s.reverse) 
        yield (c match{
            case 'T' => 'A'
            case 'A' => 'T'
            case 'C' => 'G'
            case 'G' => 'C'
            }
        ) 
  }

//Counts # of similar chars in the two strings
  def pointMutations(s:String, s2:String): Int ={
    (for(i<-0 until s.length; if(s(i)!=s2(i))) yield s(i)).length
  } 

//finds where s2 shows up in s (indexing starts at 1 in returned list)
  def findMotif(s:String, s2:String): List[Int] ={
    (for(i<-0 to s.length-s2.length if(s.substring(i, s2.length+i) ==s2&& s2!="")) yield i+1).toList
  }  

}
